#include <iostream>
#include <vector>

#include "circle.h"
#include "rectangle.h"
#include "rightTriangle.h"

int main()
{
    std::vector<Shape*> shapes;
    
    for(int i = 0; i < shapes.size(); i++) {

    }

    return 0;
}
